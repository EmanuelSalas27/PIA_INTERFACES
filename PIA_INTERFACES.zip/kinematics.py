import math

def tand(x):
    return math.tan(x)


def sind(x):
    return math.sin(x)


def cosd(x):
    return math.cos(x)


def atand(x):
    return math.degrees(math.atan(x))

def atand2(x,y):
    return math.degrees(math.atan2(x,y))

def asind(x):
    return math.degrees(math.asin(x))


def acosd(x):
    return math.degrees(math.acos(x))


l1 = 11
l2 = 3.5
l3 = 9.5
l4 = 8.5

def forward_kinematics(q1,q2,q3):
    q1 = q1*math.pi/180
    q2 = q2*math.pi/180
    q3 = q3*math.pi/180

    # CINEMATICA DIRECTA

    y = -l2 * sind(q1) + l3 * cosd(q1) * cosd(q2) + l4 * cosd(q1) * cosd(q2 + q3)
    x = -l2 * cosd(q1) - l3 * sind(q1) * cosd(q2) - l4 * sind(q1) * cosd(q2 + q3)
    z = l1 + l3 * sind(q2) + l4 * sind(q2 + q3)
    return [round(x,3),round(y,3),round(z,3)]

def inverse_kinematics(x,y,z):

    # CINEMATICA INVERSA
    q1 = atand2(-x,y) - asind(l2 / math.sqrt(x**2 + y**2))
    alfa = atand2(-x,y)
    beta = asind(l2 / math.sqrt(x**2 + y**2))
    rr = (math.sqrt(x**2 + y**2)) * cosd(beta*math.pi/180)
    q3 = 180 - (acosd((l4**2 + l3**2 - (math.sqrt(rr**2+(z-l1)**2))**2) / (2*l4*l3)))
    phi = atand2((z-l1) , rr)
    angulo = acosd((-(l4**2) + l3**2 + (math.sqrt(rr**2 + (z - l1)**2))**2) / (2*l3*(math.sqrt(rr**2 + (z-l1)**2))))
    q2 = phi - angulo
    return [round(q1,3),round(q2,3),round(q3,3)]

"""
[x,y,z] = forward_kinematics(280,10,0)
print(x,y,z)
[q1,q2,q3] = inverse_kinematics(x,y,z)
print(q1,q2,q3)
"""
