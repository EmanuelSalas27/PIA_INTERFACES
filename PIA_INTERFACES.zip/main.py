import tkinter
from tkinter import messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from Serial import get_ports, send_message
import idiomas
from kinematics import forward_kinematics, inverse_kinematics
from PIL import ImageTk, Image

PRIMARY_COLOR = '#252323'
SECONDARY_COLOR = '#FFFFFF'


class Interfaz:

    def __init__(self,i = idiomas.spanish):
        self.idioma = i
        self.AED = [0, 0, 0, 0]
        self.pos_ant = []
        self.pos_sig = []
        self.selected_port = None
        self.window = tkinter.Tk()
        self.window.title(self.idioma[0])
        self.center_window()
        self.window.resizable(False, False)
        self.window.config(bg=PRIMARY_COLOR, padx=10, pady=10)
        self.window.rowconfigure([0, 1, 2], weight=1)
        self.window.columnconfigure([0, 1, 2, 3], weight=1)

        self.frame1 = tkinter.LabelFrame(text=self.idioma[1], bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.home_button = tkinter.Button(self.frame1, text=self.idioma[2], bg=SECONDARY_COLOR,
                                          highlightbackground=PRIMARY_COLOR, command=self.go_home)
        self.home_button.pack(expand=True)
        self.run_button = tkinter.Button(self.frame1, text=self.idioma[3], bg=SECONDARY_COLOR, highlightbackground=PRIMARY_COLOR,
                                         command=self.run)
        self.run_button.pack(expand=True)
        self.frame1.grid(column=0, row=0, sticky="WENS", padx=5)

        self.frame2 = tkinter.LabelFrame(text=self.idioma[4], bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.frame2.columnconfigure([0, 1], weight=1)
        self.frame2.rowconfigure([0, 1, 2, 3], weight=1)

        self.q1_label = tkinter.Label(self.frame2, text='q1:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.q1_label.grid(column=0, row=0)
        self.q1_entry = tkinter.Entry(self.frame2, width=10, highlightbackground=PRIMARY_COLOR,
                                      textvariable=tkinter.StringVar(value='0'))
        self.q1_entry.grid(column=1, row=0)
        self.q1_entry.focus()

        self.q2_label = tkinter.Label(self.frame2, text='q2:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.q2_label.grid(column=0, row=1)
        self.q2_entry = tkinter.Entry(self.frame2, width=10, highlightbackground=PRIMARY_COLOR,
                                      textvariable=tkinter.StringVar(value='0'))
        self.q2_entry.grid(column=1, row=1)

        self.q3_label = tkinter.Label(self.frame2, text='q3:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.q3_label.grid(column=0, row=2)
        self.q3_entry = tkinter.Entry(self.frame2, width=10, highlightbackground=PRIMARY_COLOR,
                                      textvariable=tkinter.StringVar(value='0'))
        self.q3_entry.grid(column=1, row=2)

        self.calculate_button_joins = tkinter.Button(self.frame2, text=self.idioma[5], bg=SECONDARY_COLOR,
                                                     highlightbackground=PRIMARY_COLOR,
                                                     command=self.calculate_joins)
        self.calculate_button_joins.grid(column=0, row=3, columnspan=3)

        self.frame2.grid(column=1, row=0, sticky="WENS", padx=5)

        self.frame3 = tkinter.LabelFrame(text=self.idioma[6], bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.frame3.columnconfigure([0, 1], weight=1)
        self.frame3.rowconfigure([0, 1, 2, 3], weight=1)

        self.x_label = tkinter.Label(self.frame3, text='X:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.x_label.grid(column=0, row=0)
        self.x_entry = tkinter.Entry(self.frame3, width=10, highlightbackground=PRIMARY_COLOR)
        self.x_entry.grid(column=1, row=0)

        self.y_label = tkinter.Label(self.frame3, text='Y:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.y_label.grid(column=0, row=1)
        self.y_entry = tkinter.Entry(self.frame3, width=10, highlightbackground=PRIMARY_COLOR)
        self.y_entry.grid(column=1, row=1)

        self.z_label = tkinter.Label(self.frame3, text='Z:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.z_label.grid(column=0, row=2)
        self.z_entry = tkinter.Entry(self.frame3, width=10, highlightbackground=PRIMARY_COLOR)
        self.z_entry.grid(column=1, row=2)

        self.calculate_button_positions = tkinter.Button(self.frame3, text=self.idioma[5], bg=SECONDARY_COLOR,
                                                         highlightbackground=PRIMARY_COLOR,
                                                         command=self.calculate_positions)
        self.calculate_button_positions.grid(column=0, row=3, columnspan=3)

        self.frame3.grid(column=2, row=0, sticky="WENS", padx=5)

        self.frame4 = tkinter.LabelFrame(text=self.idioma[7], bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.on_button = tkinter.Button(self.frame4, text=self.idioma[8], bg=SECONDARY_COLOR,
                                        highlightbackground=PRIMARY_COLOR,
                                        command=self.effector_on)
        self.on_button.pack(expand=True)
        self.off_button = tkinter.Button(self.frame4, text=self.idioma[9], bg=SECONDARY_COLOR,
                                         highlightbackground=PRIMARY_COLOR,
                                         command=self.effector_off)
        self.off_button.pack(expand=True)
        self.off_button['state'] = 'disabled'
        self.frame4.grid(column=3, row=0, sticky="WENS", padx=5)

        self.frame5 = tkinter.LabelFrame(text=self.idioma[10], bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.figure = plt.Figure(figsize=(3, 3), dpi=100)
        self.ax = self.figure.add_subplot(projection='3d')
        self.chart_type = FigureCanvasTkAgg(self.figure, self.frame5)
        self.ax.set_title(self.idioma[11])
        self.chart_type.get_tk_widget().pack(expand=True, fill='both', padx=10, pady=10)
        self.frame5.grid(column=2, row=1, columnspan=4, sticky="WENS", padx=5)

        self.frameimage = tkinter.LabelFrame(text=self.idioma[12], bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.canvas = tkinter.Canvas(self.frameimage, width=300, height=300)
        img = Image.open('assets/robot.png')
        resized_image = img.resize((300, 300))
        new_image = ImageTk.PhotoImage(resized_image)
        self.canvas.create_image(155, 160, anchor='center', image=new_image)
        self.canvas.pack(expand=True, fill='both', padx=10, pady=10)
        self.frameimage.grid(column=0, row=1, columnspan=2, sticky="WENS", padx=5)

        self.frame6 = tkinter.LabelFrame(text=self.idioma[13], height=100, width=100, bg=PRIMARY_COLOR,
                                         fg=SECONDARY_COLOR)
        self.frame7 = tkinter.LabelFrame(self.frame6, text=self.idioma[14], height=100, width=100, bg=PRIMARY_COLOR,
                                         fg=SECONDARY_COLOR,
                                         padx=5,
                                         pady=5)
        self.ports_list = tkinter.Listbox(self.frame7, width=20, height=5)
        self.ports_list.pack()

        self.viable_ports = get_ports()
        self.ports_list.insert(0, *self.viable_ports)

        self.select_port_btn = tkinter.Button(self.frame7, text=self.idioma[15], bg=SECONDARY_COLOR,
                                              highlightbackground=PRIMARY_COLOR, command=self.set_port)
        self.select_port_btn.pack()
        self.search_port_btn = tkinter.Button(self.frame7, text=self.idioma[16], width=10, bg=SECONDARY_COLOR,
                                              highlightbackground=PRIMARY_COLOR,
                                              command=self.search_port)
        self.search_port_btn.pack()
        self.frame07 = tkinter.LabelFrame(self.frame6, text="IDIOMAS", height=100, width=100, bg=PRIMARY_COLOR,
                                         fg=SECONDARY_COLOR,
                                         padx=5,
                                         pady=5)
        self.english_button = tkinter.Button(self.frame07, text="INGLES", width=10, bg=SECONDARY_COLOR,
                                              highlightbackground=PRIMARY_COLOR,
                                              command=self.change_english)
        self.english_button.pack(expand=True)
        self.spanish_button = tkinter.Button(self.frame07, text="ESPAÑOL", width=10, bg=SECONDARY_COLOR,
                                              highlightbackground=PRIMARY_COLOR,
                                              command=self.change_spanish)
        self.spanish_button.pack(expand=True)
        self.frame7.grid(column=0, row=0, sticky="WENS", padx=30)
        self.frame07.grid(column=1, row=0, sticky="WENS", padx=30)
        self.frame6.grid(column=2, row=2, sticky="WENS", columnspan=4, padx=5)
        self.frame8 = tkinter.LabelFrame(text=self.idioma[17], height=100, width=100, bg=PRIMARY_COLOR,
                                         fg=SECONDARY_COLOR)
        self.portframe = tkinter.LabelFrame(self.frame8, text=self.idioma[18], bg=PRIMARY_COLOR,
                                         fg=SECONDARY_COLOR)
        self.portlabel = tkinter.Label(self.portframe, text='No Port', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR,  width=20)
        self.portlabel.pack()
        self.portframe.pack(expand=True)
        self.dofframe = tkinter.LabelFrame(self.frame8, text="DOF [q1,q2,q3,E]", height=50, width=200, bg=PRIMARY_COLOR,
                                            fg=SECONDARY_COLOR)
        self.doflabel = tkinter.Label(self.dofframe, text='[0.0,0.0,0.0,0]', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR, width=20)
        self.doflabel.pack()
        self.dofframe.pack(expand=True)
        self.coordframe = tkinter.LabelFrame(self.frame8, text="COORDINATES [x,y,z]", height=50, width=200, bg=PRIMARY_COLOR,
                                           fg=SECONDARY_COLOR)
        self.coordlabel = tkinter.Label(self.coordframe, text='', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR,
                                      width=20)
        self.coordlabel.pack()
        self.coordframe.pack(expand=True)
        self.frame8.grid(column=0, row=2, sticky="WENS", columnspan=2, padx=5)
        self.window.mainloop()

    def calculate_joins(self):

        x_value = float(self.x_entry.get())
        y_value = float(self.y_entry.get())
        z_value = float(self.z_entry.get())

        if x_value != '' and y_value != '' and z_value != '':
            [q1, q2, q3] = inverse_kinematics(x_value, y_value, z_value)
            self.q1_entry.delete(0, 'end')
            self.q2_entry.delete(0, 'end')
            self.q3_entry.delete(0, 'end')
            self.q1_entry.insert(0, q1)
            self.q2_entry.insert(0, q2)
            self.q3_entry.insert(0, q3)
            self.doflabel['text'] = str([q1,q2,q3,self.AED[3]])

        else:
            messagebox.showwarning('Error', 'Introduce los valores de X,Y,Z')

    def calculate_positions(self):
        q1_value = float(self.q1_entry.get())
        q2_value = float(self.q2_entry.get())
        q3_value = float(self.q3_entry.get())

        if q1_value != '' and q2_value != '' and q3_value != '':

            if -90 <= q1_value <= 180 and -45 <= q2_value <= 90 and -90 <= q3_value <= 90:
                [x, y, z] = forward_kinematics(q1_value, q2_value, q3_value)
                self.x_entry.delete(0, 'end')
                self.y_entry.delete(0, 'end')
                self.z_entry.delete(0, 'end')
                self.x_entry.insert(0, x)
                self.y_entry.insert(0, y)
                self.z_entry.insert(0, z)
                self.coordlabel['text'] = str([x,y,z])
                self.plot(x, y, z)

            else:
                messagebox.showwarning('Error',
                                       'Introduce valores dentro del rango permitido:\nq1: 0 a 360\nq2: 0 a 180\nq3: '
                                       '0 a '
                                       '180')

        else:
            messagebox.showwarning('Error', 'Introduce los valores de q1,q2,q3')

    def set_port(self):
        if self.ports_list.curselection():
            self.selected_port = self.viable_ports[self.ports_list.curselection()[0]]
            print(self.selected_port)
            self.portlabel['text'] = self.selected_port

    def search_port(self):
        self.viable_ports = get_ports()
        self.ports_list.delete(0, 'end')
        self.ports_list.insert(0, *self.viable_ports)

    def effector_on(self):
        self.AED[3] = 1
        self.off_button['state'] = 'active'
        self.on_button['state'] = 'disabled'

    def effector_off(self):
        self.AED[3] = 0
        self.on_button['state'] = 'active'
        self.off_button['state'] = 'disabled'

    def set_joins(self):
        q1 = float(self.q1_entry.get())
        q2 = float(self.q2_entry.get())
        q3 = float(self.q3_entry.get())
        self.AED[0:3] = [q1, q2, q3]


    def run(self):
        self.set_joins()
        self.calculate_positions()
        self.doflabel['text'] = str(self.AED)
        send_message(str(self.AED).replace('[', '<').replace(']', '>'), self.selected_port)

    def go_home(self):
        self.q1_entry.delete(0, 'end')
        self.q2_entry.delete(0, 'end')
        self.q3_entry.delete(0, 'end')
        self.q1_entry.insert(0, 0.0)
        self.q2_entry.insert(0, 0.0)
        self.q3_entry.insert(0, 0.0)
        self.calculate_positions()
        self.run()

    def plot(self, x, y, z):

        if self.pos_ant:
            self.pos_sig = [x, y, z]
        else:
            self.pos_ant = [x, y, z]

        print(self.pos_sig, self.pos_ant)
        self.frame5.destroy()
        self.frame5 = tkinter.LabelFrame(text="PLOT", bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
        self.figure = plt.Figure(figsize=(3, 3), dpi=100)
        self.ax = self.figure.add_subplot(projection='3d')
        chart_type = FigureCanvasTkAgg(self.figure, self.frame5)
        self.ax.set_title("Position of the Final Effector")

        xi, yi, zi = self.pos_ant

        self.ax.scatter(xi, yi, zi, label='Current Position')
        if self.pos_sig:
            xd, yd, zd = self.pos_sig
            self.ax.scatter(xd, yd, zd, marker="x", c="red", label='Next Position')
        self.ax.legend()
        chart_type.get_tk_widget().pack(expand=True, fill='both', padx=10, pady=10)
        self.frame5.grid(column=2, row=1, columnspan=4, sticky="WENS", padx=5)

    def center_window(self, width=700, height=700):
        # get screen width and height
        screen_width = self.window.winfo_screenwidth()
        screen_height = self.window.winfo_screenheight()

        # calculate position x and y coordinates
        x = (screen_width / 2) - (width / 2)
        y = (screen_height / 2) - (height / 2)
        self.window.geometry('%dx%d+%d+%d' % (width, height, x, y))

    def change_spanish(self):
        self.__init__(idiomas.spanish)

    def change_english(self):
        self.__init__(idiomas.english)

interfaz1 = Interfaz()
